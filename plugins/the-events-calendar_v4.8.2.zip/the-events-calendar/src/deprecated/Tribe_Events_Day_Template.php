<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Template__Day' );


	class Tribe_Events_Day_Template extends Tribe__Events__Template__Day {

	}